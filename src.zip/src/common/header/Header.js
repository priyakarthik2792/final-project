import React from 'react';
import {ReactComponent as Logo} from '../../assets/logo.svg';
import { Button } from '@material-ui/core';
import LogoutIcon from '@material-ui/icons/ExitToApp';
import LoginIcon from '@material-ui/icons/AccountCircle';
import ButtonGroup from "@material-ui/core/ButtonGroup";
import Login from "../../common/header/Login";
import Register from "../../common/header/Register";
import './Header.css';
const Header = () => {
    return(
        <nav>
            <div className='div-header'>
                <div className='div-svg'>
                    <Logo/>
                </div>
                <div className='button-header' style={{ marginTop: "10px"}}>
                <ButtonGroup variant="contained">
                 <Button endIcon={<LoginIcon />} color="primary">
                  Login
                 </Button>
                <Button startIcon={<LogoutIcon />} color="primary">
                  Logout
                </Button>
                </ButtonGroup>
                </div>
                <div className='bookbtn-header'>
                <Button variant="contained" color="primary">
                     Book Show
                </Button>

                </div>
            </div>
        </nav>
    )
       
    
}
export default Header;